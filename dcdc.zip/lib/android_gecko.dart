import 'dart:convert';

import 'package:flutter/services.dart';

import 'platform_ui.dart';

/// Android only: the built-in Firefox engine (GeckoView) sign-in screen.
///
/// Google blocks sign-in inside Android WebView, but GeckoView is a real
/// browser engine. The user signs in once; its private profile keeps the
/// Google session, and the Gemini cookies can be read again silently when
/// the app's copy expires (see android_native/ for the native side).
class AndroidGecko {
  AndroidGecko._();

  static const _ch = MethodChannel('ais/gecko');
  static const _saCh = MethodChannel('ais/stable_audio');

  static bool get supported => isAndroidUi;

  static List<Map<String, dynamic>> _decode(String? json) {
    if (json == null || json.trim().isEmpty) return const [];
    final v = jsonDecode(json);
    if (v is! List) return const [];
    return [
      for (final c in v)
        if (c is Map) c.cast<String, dynamic>()
    ];
  }

  /// Opens the sign-in screen; completes when it closes. Empty list = not
  /// signed in.
  static Future<List<Map<String, dynamic>>> signIn() async =>
      _decode(await _ch.invokeMethod<String>('signIn'));

  /// Loads Gemini invisibly in the signed-in profile and returns the
  /// renewed Gemini cookies (empty = profile not signed in).
  static Future<List<Map<String, dynamic>>> refresh() async =>
      _decode(await _ch.invokeMethod<String>('refresh')
          .timeout(const Duration(seconds: 60)));

  /// Opens Stable Audio in GeckoView so the user can sign in and returns
  /// `{accessToken, refreshToken, clientId}`.
  static Future<Map<String, dynamic>?> signInStableAudio() async {
    final raw = await _ch.invokeMethod<String>('stableAudioSignIn');
    if (raw == null || raw.trim().isEmpty) return null;
    final v = jsonDecode(raw);
    return v is Map ? v.cast<String, dynamic>() : null;
  }

  /// Creates a fresh Stable Audio account in a private GeckoView session
  /// using [email]/[password] and [onPollOtp] to fetch the 6-digit OTP.
  static Future<Map<String, dynamic>?> autoCreateStableAudio({
    required String email,
    required String password,
    required Future<String?> Function() onPollOtp,
  }) async {
    _saCh.setMethodCallHandler((call) async {
      if (call.method == 'pollStableAudioOtp') {
        return await onPollOtp();
      }
      return null;
    });
    try {
      final raw = await _ch
          .invokeMethod<String>('stableAudioAutoCreate', {
            'email': email,
            'password': password,
          })
          .timeout(const Duration(seconds: 130));
      if (raw == null || raw.trim().isEmpty) return null;
      final v = jsonDecode(raw);
      return v is Map ? v.cast<String, dynamic>() : null;
    } finally {
      _saCh.setMethodCallHandler(null);
    }
  }
}
